package com.quantumspace.activitylifecycle

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity() {



    lateinit var etNumber: EditText
    lateinit var etPassword: EditText
    lateinit var btnChantIn: Button
    lateinit var txtForgotPassword: TextView
    lateinit var txtRegister: TextView
    val realMobile="9840652843"
    val realPass= arrayOf("123","456","789")

    lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.login)

        sharedPreferences=getSharedPreferences(getString(R.string.preference_file_name), Context.MODE_PRIVATE)

        val isLoggedIn=sharedPreferences.getBoolean("isLoggedIn",false)


        if(isLoggedIn){
            val intent= Intent(this@LoginActivity, MainActivity::class.java)
            finish()
        }
            title="Log In"

            etNumber= findViewById(R.id.etNumber)
            etPassword= findViewById(R.id.etPassword)
            btnChantIn= findViewById(R.id.btnChantIn)
            txtForgotPassword= findViewById(R.id.txtForgotPassword)
            txtRegister= findViewById(R.id.txtRegister)

            btnChantIn.setOnClickListener {
                val mobile= etNumber.text.toString()
                val password= etPassword.text.toString()
                var appName= "The Eight chakra"
                val intent = Intent(this@LoginActivity, MainActivity::class.java)

                if (mobile==realMobile){
                    if(password==realPass[0]) {
                        appName = "Rajeswari"
                        savedPreference(appName)
                        startActivity(intent)


                    } else if(password==realPass[1]){
                        appName="Sathguru"
                        savedPreference(appName)
                        startActivity(intent)


                    } else if(password==realPass[2]) {
                        appName = "Raja"
                        savedPreference(appName)
                        startActivity(intent)
                    }
                }
                else{
                    Toast.makeText(this@LoginActivity,"Incorrect Password",Toast.LENGTH_LONG).show()
                }
            }
    }


    override fun onPause() {
        super.onPause()
        finish()
    }
    fun savedPreference(title: String){
        sharedPreferences.edit().putBoolean("isLoggedIn",true).apply()
        sharedPreferences.edit().putString("title",title).apply()
    }

}